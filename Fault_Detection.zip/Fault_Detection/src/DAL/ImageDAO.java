/**
 * 
 */
package DAL;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Image;

/**
 * @author hedy
 *
 */
public class ImageDAO {
	// store .npy as .png
	//static String import_path = "D:/Python_projects/labelbox_helloworld/Upload.py";
	static String import_path = "./pythonFiles/Upload.py";
	/**
	 * 
	 * @param path  the numpy file path
	 * @param dir   the cut direction 0 or 1 or 2
	 * @return
	 */
	public static boolean insertDataset(String path, String dir, String datasetName, String from, String to){
		String[] arguments = new String[] {"python", import_path, path, dir, datasetName, from, to};
        int re = 1;
		try {
            Process process = Runtime.getRuntime().exec(arguments);
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {  
              System.out.println(line);  
          }  
          in.close();
          re = process.waitFor();  
        } catch (Exception e) {
            e.printStackTrace();
        }
		return re == 0;
	}
	
	public static boolean insertImage(String id, String path, String datasetName){
		Connection conn = JDBCTool.getConnection();
		int re = 0;
		try {
			PreparedStatement ps = conn.prepareStatement("insert into images value(?,?,?)");
			ps.setString(1, id);
			ps.setString(2, path);
			ps.setString(3, datasetName);
			re = ps.executeUpdate();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return re == 1;
	}
	
	public static ArrayList<Image> getDataset(String name){
		ArrayList<Image> images = new ArrayList<Image>();
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from images where datasetName = ?"); 
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String i = rs.getString("id");
				String p = rs.getString("path");
				String n = rs.getString("datasetName");
				Image img = new Image(i,p,n);
				images.add(img);
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return images;
	}
	
	public static ArrayList<String> getAllDatasetName(){
		ArrayList<String> names = new ArrayList<>();
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select distinct(datasetName) from images");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String s = rs.getString("datasetName");
				names.add(s);
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return names;
	}
	
	public static boolean deleteDataset(String name){
		boolean delete = false;
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("delete from images where datasetName = ?");
			ps.setString(1, name);
			delete = ps.executeUpdate() != 0;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
	public static boolean deleteImage(String id){
		boolean delete = false;
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("delete from images where id = ?");
			ps.setString(1,id);
			delete = ps.executeUpdate() == 1;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
	
}
