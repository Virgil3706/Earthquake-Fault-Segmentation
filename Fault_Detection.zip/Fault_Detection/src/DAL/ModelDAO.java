/**
 * 
 */
package DAL;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Model;

/**
 * @author hedy
 *
 */
public class ModelDAO {

	public static boolean createModel(String name, String path, String createBy){
		Connection conn = JDBCTool.getConnection();
		int r = 0;
		java.util.Date d = new java.util.Date();
		try {
			PreparedStatement pst = conn.prepareStatement("insert into models values(?,?,?,?,?);");
			pst.setString(1, name);
			pst.setDate(2, new Date(d.getTime()));
			pst.setDate(3, new Date(d.getTime()));
			pst.setString(4, path);
			pst.setString(5, createBy);
			System.out.println("model sql:"+pst);
			r = pst.executeUpdate();
			pst.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return r == 1;
		
	}
	
	public static boolean deleteModel(String path){
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement("delete from models where modelPath = ?;");
			pst.setString(1, path);
			return pst.executeUpdate() != 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static ArrayList<Model> getAllModels(){
		Connection conn = JDBCTool.getConnection();
		ArrayList<Model> models = new ArrayList<Model>();
		try {
			PreparedStatement pst = conn.prepareStatement("select * from models;");
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				String name = rs.getString("name"); 
				Date createDate = rs.getDate("createDate"); 
				Date updateDate = rs.getDate("updateDate"); 
				String path = rs.getString("modelPath");
				String createBy = rs.getString("createBy");
				Model m = new Model(name, createDate, updateDate, path, createBy);
				models.add(m);
			}
			rs.close();
			pst.close();
			conn.close();
			return models;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getPathByName(String name){
		String path = "";
		Connection cnn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = cnn.prepareStatement("select modelPath from models where name = ?;");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				path = rs.getString("modelPath");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return path;
	}
}
