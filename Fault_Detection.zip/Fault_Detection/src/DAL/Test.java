/**
 * 
 */
package DAL;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;


/**
 * @author hedy
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		boolean upload = ImageDAO.insertDataset("D:/BDIC_Learning/Final_Project/FYP_data/fault_sub_350IL_500t_1200XL.npy","0","ttt","1","2");
//		System.out.println("upload? "+upload);
//		ArrayList<Image> imgs = ImageDAO.getDataset("seis");
//		for (int i = 0; i < imgs.size(); i++) {
//			System.out.println(imgs.get(i).getId());
//		}
//		boolean d = ImageDAO.deleteDataset("ttt");
//		System.out.println("delete? "+d);
//		ArrayList<String> names = ImageDAO.getAllDatasetName();
//		for(String n : names){
//			System.out.println("name: "+n);
//		}
//		System.out.println(ModelDAO.getPathByName("UNET"));
//		String[] arguments = new String[] {"python", "C:/Users/hedan/.PyCharmCE2019.1/config/scratches/scratch.py", "path", "name"};
//        int re = 1;
//		try {
//            Process process = Runtime.getRuntime().exec(arguments);
//            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"GBK"));
//            String line = null;
//          while ((line = in.readLine()) != null) {  
//              System.out.println(line);  
//          }  
//          in.close();
//          re = process.waitFor();
//          System.out.println(re);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//		ModelDAO.createModel("UNET-TEST", "D:/BDIC_Learning/Final_Project/code/model_best.pth", "hdy");
//		boolean i = DatasetDAO.insertD("unet-test", "D:/BDIC_Learning/Final_Project/FYP_data/seis_sub_350IL_500t_1200XL.npy");
//		System.out.println(i);
//		System.out.println("UNET-TESE".toLowerCase());
//		System.out.println(ModelDAO.getPathByName("UNET-TEST".toLowerCase()));
//		System.out.println(ImageDAO.insertImage("a.png", "asdsadsadas", "a"));
	}

}
