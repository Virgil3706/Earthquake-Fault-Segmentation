/**
 * 
 */
package DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Manager;

/**
 * @author hedy
 *
 */
public class ManagerDAO {
	public static Manager login(String m_name, String password) {
		Connection conn = null;
		try {	
			conn = JDBCTool.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM managers WHERE mname='"+m_name+"' AND password='"+password+"'");
			System.out.println("SELECT * FROM managers WHERE mname='"+m_name+"' AND password='"+password+"'");
			if(rs.next()) {
				String mn = rs.getString("mname");
				String p = rs.getString("password");
				String add = rs.getString("address");
				Manager m = new Manager(mn,p,add);
				rs.close();
				st.close();
				conn.close();
				return m;
			}
			rs.close();
			st.close();
			conn.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		finally {
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		
		return null;
	}
	
	public static boolean register(String name, String password, String email){
		Connection conn = null;
		try {	
			conn = JDBCTool.getConnection();
			PreparedStatement pst = conn.prepareStatement("insert into managers values (?,?,?);");
            pst.setString(1, name);
            pst.setString(2, password);
            pst.setString(3, email);
            System.out.println("insert into managers values("+name+","+password+","+email+")");
            return pst.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return false;
	}
}
