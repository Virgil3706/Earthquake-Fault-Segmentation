/**
 * 
 */
package DAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Dataset;

/**
 * @author hedy
 *
 */
public class DatasetDAO {
	public static boolean insertD(String name, String path){
		boolean i = false;
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("insert into datasets values(?,?);");
			ps.setString(1, name );
			ps.setString(2, path );
			int u = ps.executeUpdate();
			i = u==1;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	
	public static boolean deleteByName(String name){
		boolean d = false;
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("delete from dataset where dname = ?;");
			ps.setString(1, name );
			int u = ps.executeUpdate();
			d = u==1;
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return d;
	}
	
	public static String getDPathByName(String name){
		String path = "";
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select from datasets where dname = ?");
			ps.setString(1, name );
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				path = rs.getString("dpath");
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return path;
	}
	public static ArrayList<Dataset> getAllDatasets(){
		ArrayList<Dataset> ds = new ArrayList<Dataset>();
		Connection conn = JDBCTool.getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from datasets;");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String path = rs.getString("dpath");
				String name = rs.getString("dname");
				Dataset d = new Dataset(name, path);
				ds.add(d);
			}
			rs.close();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ds;
	}
}
