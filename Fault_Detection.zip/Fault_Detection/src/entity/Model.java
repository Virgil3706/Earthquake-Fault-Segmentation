/**
 * 
 */
package entity;

import java.sql.Date;

/**
 * @author hedy
 *
 */
public class Model {
	private String name;
	private Date createDate;
	private Date updateDate;
	private String path;
	private String createBy;
	/**
	 * 
	 */
	public Model(String name, Date createDate, Date updateDate, String path, String createBy) {
		this.name = name;
		this.createDate = createDate;
		this.updateDate = updateDate;
		this.path = path;
		this.createBy = createBy;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

}
