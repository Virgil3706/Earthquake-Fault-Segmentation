/**
 * 
 */
package entity;

/**
 * @author hedy
 *
 */
public class Image {
	private String id = "";
	private String path = "";
	private String datasetName = "";
	/**
	 * 
	 */
	public Image(String id, String path, String datasetName ) {
		this.setId(id);
		this.setPath(path);
		this.setDatasetName(datasetName);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getDatasetName() {
		return datasetName;
	}
	public void setDatasetName(String datasetName) {
		this.datasetName = datasetName;
	}

}
