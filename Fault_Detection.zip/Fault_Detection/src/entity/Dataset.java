/**
 * 
 */
package entity;

/**
 * @author hedy
 *
 */
public class Dataset {
	private String dname = "";
	private String dpath = "";

	/**
	 * 
	 * @param dname
	 * @param dpath
	 */

	public Dataset(String dname, String dpath) {
		this.setDname(dname);
		this.setDpath(dpath);
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDpath() {
		return dpath;
	}

	public void setDpath(String dpath) {
		this.dpath = dpath;
	}

}
