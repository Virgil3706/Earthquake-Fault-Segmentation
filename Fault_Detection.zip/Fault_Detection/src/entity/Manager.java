/**
 * 
 */
package entity;

/**
 * @author hedy
 *
 */
public class Manager {
	private String m_name;
	private String password;
	private String email;
	public Manager(String m_name, String password, String email) {
		super();
		this.m_name = m_name;
		this.password = password;
		this.email = email;
	}
	public String getm_name() {
		return m_name;
	}
	public void setm_name(String m_name) {
		this.m_name = m_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
