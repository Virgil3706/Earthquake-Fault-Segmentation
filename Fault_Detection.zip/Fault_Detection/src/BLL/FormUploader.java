/**
 * 
 */
package BLL;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAL.ImageDAO;
import entity.Image;

/**
 * @author hedy
 *
 */
@WebServlet("/FormUploader")
public class FormUploader extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private static String import_path = "D:/oop/Fault_Detection/pythonFiles/Upload.py";
	
	public FormUploader(){
		super();
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res){
		String[] s = new String[5];
		s[0] = req.getParameter("mpath");
		s[1] = req.getParameter("dPath");
		s[2] = req.getParameter("dir");
		s[3] = req.getParameter("indexFrom");
		s[4] = req.getParameter("indexTo");
//		ArrayList<String> imgs = applyModel("ssssssss", "D:/BDIC_Learning/Final_Project/FYP_data/fault_sub_350IL_500t_1200XL.npy", "1", "1", "4");
		ArrayList<String> results = applyModel(s[0], s[1], s[2], s[3], s[4]);
		System.out.println("imgs:"+results.get(0));
		req.setAttribute("ch", results.get(0));
		req.setAttribute("cw", results.get(1));
//		ArrayList<String> imgs = new ArrayList<String>();
		String datasetName = s[0].substring(s[0].length()-6,s[0].length()-4)+"_"+s[1].substring(s[1].length()-6,s[1].length()-4);
		req.setAttribute("resultDataset", datasetName);
		ImageDAO.deleteDataset(datasetName);
		for (int i = 2; i < results.size(); i++) {
			String id = datasetName+"_"+(i-2)+".png";
//			imgs.add(results.get(i));
			ImageDAO.insertImage(results.get(i), "/file/", datasetName);
		}
//		req.setAttribute("images", imgs);
//		System.out.println("req:"+((ArrayList<String>)req.getSession().getAttribute("images"))==null);
		try {
			String url = "present.jsp?mname="+req.getParameter("mname")+"&cp=1";
			req.getRequestDispatcher(url).forward(req,res);
		} catch (IOException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ArrayList<String> applyModel(String mpath, String dpath, String dir, String from, String to){
		ArrayList<String> results = new ArrayList<String>();
		String[] arguments = new String[] {"python", import_path, mpath, dpath, dir, from, to};
//		int re = 1;
		try {
            Process process = Runtime.getRuntime().exec(arguments);
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {  
            	results.add(line);
                System.out.println("line: "+line);  
          }
          in.close();
          process.waitFor();  
        } catch (Exception e) {
            e.printStackTrace();
        }
		return results;
	}
	
//	public static void main(String[] args) {
//		ArrayList<String> imgs = applyModel("ssssssss", "D:/BDIC_Learning/Final_Project/FYP_data/seis_sub_350IL_500t_1200XL.npy", "1", "1", "4");
//		System.out.println(imgs==null);
//		System.out.println(imgs);
//	}
	
}
