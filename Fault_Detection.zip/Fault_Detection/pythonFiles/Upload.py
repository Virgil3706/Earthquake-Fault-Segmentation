import numpy as np
import scipy.misc
from sys import argv
import os
import pymysql
import imageio

dest_path = "D:/BDIC_Learning/Final_Project/FYP_data/img/"


class Upload:

    def __init__(self):
        self.__db_host = "localhost"
        self.__db_port = 3306
        self.__db_user = "root"
        self.__db_password = "HDY719hdy"
        self.__db_database = "fault_detection"
        # 链接数据库

    def isconnectionopen(self):
        self.__db = pymysql.connect(
            host=self.__db_host,
            user=self.__db_user,
            password=self.__db_password,
            database=self.__db_database,
            charset='utf8'
        )

    def linesinsert(self, name, path, dataset):
        try:
            # 连接数据库
            self.isconnectionopen()
            # 创建游标
            global cursor
            cursor = self.__db.cursor()
            # sql命令
            sql = "insert into images(id,path,datasetName) value(%s,%s,%s)"
            # 执行sql命令
            cursor.execute(sql, (name, path, dataset))
        except Exception as e:
            print(e)
        finally:
            # 关闭游标
            cursor.close()
            # 提交
            self.__db.commit()
            # 关闭数据库连接
            self.__db.close()

    # def modelSimulator(self, path, dataset):
    # 	try:
    #         # 连接数据库
    #         self.isconnectionopen()
    #         # 创建游标
    #         global cursor
    #         cursor = self.__db.cursor()
    #         # sql命令
    #         sql = "insert into datasets(dpath,dname) value(%s,%s)"
    #         # 执行sql命令
    #         cursor.execute(sql, (path, dataset))
    #     except Exception as e:
    #         print(e)
    #     finally:
    #         # 关闭游标
    #         cursor.close()
    #         # 提交
    #         self.__db.commit()
    #         # 关闭数据库连接
    #         self.__db.close()

    def load(self, path, d, f, t):
        seis = np.load(path)
        # print(seis.shape)
        for s in range(0, 3):
            # print(s)
            # print(seis.shape[s])
            if s != int(d):
                print(seis.shape[s])
        if not os.path.exists(dest_path):
            os.makedirs(dest_path)
        if int(f) >= 1 and int(t) <= seis.shape[int(d)]:
            for i in range(int(f), int(t)):
                if d == "0":
                    b = seis[i, :, :]
                elif d == "1":
                    b = seis[:, i, :]
                else:
                    b = seis[:, :, i]
                name = "testDataset" + "_" + str(i).zfill(6) + ".png"
                scipy.misc.imsave(dest_path + name, b)
                # print("i: ",i)
                # self.linesinsert(name, dest_path, dataset)
                # print(dest_path+name) <-正確寫法
                print(name)


if __name__ == "__main__":
    upld = Upload()
    # upld.load("D:/BDIC_Learning/Final_Project/FYP_data/seis_sub_350IL_500t_1200XL.npy", "1", "1", "4")
    upld.load(argv[2], argv[3], argv[4], argv[5])